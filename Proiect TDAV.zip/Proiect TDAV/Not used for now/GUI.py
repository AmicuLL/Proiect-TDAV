import tkinter as tk
import cv2
from tkinter import *
from tkinter import filedialog
from tkinter.font import Font
from tkinter import messagebox
import datetime as dt
import HOUGH

#import Functii as functions
imgPath = __file__.rsplit("\\", 1)[0] + "/Images/default.jpg"
def Validate():
        file_path = filedialog.askopenfilename() #functie care permite folosirea prompt-ului de selectare fisier si validare
        if file_path and file_path.rsplit(".",1)[1].lower() in ["jpg", "jpeg", "png", "gif", "bmp", "tiff", "tif", "webp", "bpg", "jif", "jfif"]:
            if cv2.imread(file_path) is not None:
                GUI.inputImage.config(text=f"Image selected: {file_path.split("/")[-1].rsplit(".",1)[0]}")
                if GUI.binaryIMG.get() == 1:
                    return file_path
                else:
                    return EdgeDetector(file_path) #Trebuie implementat altcumva... numa dupa ce se confirma ar trebui sa porneasca :) Sau il las asa?
            else: messagebox.showerror("ERROR","The image selected is not valid!")
        else:
            if file_path != "": 
                messagebox.showwarning("WARNING", "Just images are accepted. \n\tAllowed extensions:\n jpg jpeg png gif bmp tiff webp bpg jif jfif")
            else: 
                messagebox.showinfo("WARNING", "No image was selected.")
                GUI.inputImage.config(text="Click here to select an image | default")
            return __file__.rsplit("\\", 1)[0] + "/Images/default.jpg"

def Prompt():
    global imgPath
    imgPath = Validate()
        
def EdgeDetector(path):
    print("Converting photo into a binary & just edges... Work in progress!")
    imgName = f"[{dt.datetime.now().strftime("%Y.%m.%d")}][{dt.datetime.now().strftime("%H.%M.%S")}].jpg"
    cv2.imwrite(f"./Images/Computer-processed images/Computer-processed image GRAY{imgName}", cv2.GaussianBlur(cv2.cvtColor(cv2.imread(path, cv2.IMREAD_COLOR), cv2.COLOR_BGR2GRAY), (9, 9), 2))
    cv2.imwrite(f"./Images/Computer-processed images/Computer-processed image EDGES{imgName}",cv2.Canny(cv2.GaussianBlur(cv2.cvtColor(cv2.imread(path, cv2.IMREAD_COLOR), cv2.COLOR_BGR2GRAY), (9, 9), 2), threshold1=30, threshold2=100))
    print("Done!")
    return (__file__.rsplit("\\", 1)[0] + f"/Images/Computer-processed images/Computer-processed image EDGES{imgName}")

    
def RadiusSwitch():
    if GUI.radiusINT.get() == 1:
        GUI.inputRaza.delete(0, tk.END)
        GUI.labelInputRadius.config(font = Font(overstrike=False))
        GUI.inputRadiusMin.config(state=NORMAL)
        GUI.inputRadiusMin.insert(0, 64)
        GUI.inputRadiusMax.config(state=NORMAL)
        GUI.inputRadiusMax.insert(0, 113)
        GUI.inputRaza.config(state=DISABLED)
    else:
        GUI.inputRadiusMin.delete(0, tk.END)
        GUI.inputRadiusMax.delete(0, tk.END)
        GUI.labelInputRadius.config(font = Font(overstrike=True))
        GUI.inputRadiusMin.config(state=DISABLED)
        GUI.inputRadiusMax.config(state=DISABLED)
        GUI.inputRaza.config(state=NORMAL)
        GUI.inputRaza.insert(0, 64)

class GUI:
    window = tk.Tk()
    window.title("Berfela Ionut, Afetelor Ioana")
    window.resizable(False, False)
    
    binaryIMG = IntVar(value=1)
    radiusINT = IntVar()
    functionINT = IntVar(value=1)
    progressBar = StringVar(value="0.00%")
    
    labelImage = tk.Label(window, text="Image:").grid(row=0, column=0)
    inputImage = tk.Button(window, text="Click here to select an image | default", command=Prompt)
    inputImage.config(bg='darkred', fg='white')
    inputImage.grid(row=0, column=1, pady=10, padx=10)
    checkboxImage = tk.Checkbutton(window, text='Img binary&just edges', variable=binaryIMG, onvalue=1, offvalue=0).grid(row=0, column=2)
    
    labelRadius = tk.Label(window, text="Radius[px]:").grid(row=1, column=0)
    inputRaza = tk.Entry(window)
    inputRaza.grid(row=1, column=1)
    inputRaza.insert(0, 64)
    checkboxRaza = tk.Checkbutton(window, text='Interval of Radius?', variable=radiusINT, onvalue=1, offvalue=0, command=RadiusSwitch)
    checkboxRaza.grid(row=1, column=2)
    
    inputRadiusMin = tk.Entry(window)
    inputRadiusMin.config(state=DISABLED)
    inputRadiusMin.grid(row=2, column=0)
    labelInputRadius = tk.Label(window, text = "⇐ Min Radius[px] | [px]Max Radius ⇒", font=Font(overstrike=True))
    labelInputRadius.grid(row=2, column=1, pady=10, padx=10)
    
    inputRadiusMax = tk.Entry(window, textvariable="Max")
    inputRadiusMax.config(state=DISABLED)
    inputRadiusMax.grid(row=2, column=2)
    
    checkboxFunctie = tk.Checkbutton(window, text='Detect by func?', variable=functionINT, onvalue=1, offvalue=0)
    checkboxFunctie.grid(row=3, column=0)
    
    buttonStart = tk.Button(window, text="\t\t\tStart\t\t\t", command=HOUGH.HOUGH_Circles)
    buttonStart.grid(row=3, column=0, columnspan=3)
    
    labelProgress = tk.Label(window, text="Progress:")
    entryProgress = tk.Entry(window, state="readonly",textvariable=progressBar)
    
    #labelProgress.grid(row=4, column=0)
    #entryProgress.grid(row=4, column= 1, pady=10, padx=10)
        

GUI.window.mainloop()