import numpy as np
import cv2
import GUI as GUIFunction
from collections import defaultdict 

def HOUGH_Circles():
    #GUIFunction.GUI.labelProgress.grid(row=4, column=0)
    #GUIFunction.GUI.entryProgress.grid(row=4, column= 1, pady=10, padx=10)
    
    GUIFunction.GUI.buttonStart.config(text="Wait to finish",state="disabled")
    
    img = cv2.imread(GUIFunction.imgPath)
    img_height, img_width = img.shape[:2]
    
    GUIFunction.GUI.progressBar.set(f"{float(GUIFunction.GUI.progressBar.get().rstrip("%"))+0.01:.2f}%")
    
    #if GUIFunction.imgPath:
    #    print(f"{GUIFunction.imgPath}\nIMG Height:\t{img_height}\nIMG Width:\t{img_width}")
        
    if(GUIFunction.GUI.radiusINT.get() == 0): 
        if(GUIFunction.GUI.functionINT.get() == 1): 
            HOUGH_Circle_FunctionFixed(img, int(GUIFunction.GUI.inputRaza.get()))
        else:
            HOUGH_CirclesFixedRadius(img_height, img_width, int(GUIFunction.GUI.inputRaza.get()))
    else: 
        if(GUIFunction.GUI.functionINT.get() == 1): 
            HOUGH_Circle_FunctionVariable(img, int(GUIFunction.GUI.inputRadiusMin.get()), int(GUIFunction.GUI.inputRadiusMax.get()));
        else:
            HOUGH_CirclesVariableRadius(img_height, img_width, int(GUIFunction.GUI.inputRadiusMin.get()), int(GUIFunction.GUI.inputRadiusMax.get()))
    if (float(GUIFunction.GUI.progressBar.get().rstrip("%")) == 100):
        GUIFunction.GUI.buttonStart.config(text="Close", command=GUIFunction.GUI.window.destroy ,state="normal")
    
        
def HOUGH_CirclesFixedRadius(img_height, img_width, radius):
    print(f"imgHeight:{img_height}\nimgWidth:{img_width}\nRadius:{radius}")
    num_theta = 100
    pasTheta = int(360 / num_theta)

    edge_image = cv2.imread(GUIFunction.imgPath,cv2.IMREAD_GRAYSCALE)# cv2.Canny(cv2.imread(GUIFunction.imgPath), 100, 200)
    
    img_height, img_width = edge_image.shape[:2]
    
    theta = np.arange(0, 360, step = pasTheta) #Theta cu step, adica: step = 2 => 0 2 4 6 8 10...360
    
    cosTheta = np.cos(np.deg2rad(theta))
    sinTheta = np.sin(np.deg2rad(theta))
    
    circleCandidates = []
    for t in range(num_theta):
        circleCandidates.append((radius, int(radius * cosTheta[t]), int(radius * sinTheta[t])))

    accumulator = defaultdict(int) #se putea folosi si un dictionar normal, doar ca acesta nu "arunca" (throwing exception) cand se apeleaza un cadru neinitializat
    progres = 0
    for y in range(img_height):
        for x in range(img_width):
            progres = progres + 1  ####################################################MODIFICARE!!! NU MAI MERGE :D
            GUIFunction.GUI.progressBar.set(f"{(progres/(img_height*img_width)) * 100:.2f}%")
            if edge_image[y][x] != 0: #pixel alb
                for r, rcos_t, rsin_t in circleCandidates:
                    x_center = x - rcos_t
                    y_center = y - rsin_t
                    accumulator[(x_center, y_center, r)] += 1 #vote for current candidate
                    
    output_img = edge_image.copy()
    out_circles = []

    for candidate_circle, votes in sorted(accumulator.items(), key=lambda i: -i[1]):
        x, y, r = candidate_circle
        current_vote_percentage = votes / 3
        if current_vote_percentage >= 0.4: 
            out_circles.append((x, y, r, current_vote_percentage))
            #print(x, y, r, current_vote_percentage)
      
  
    post_process = False
    if post_process :
        pixel_threshold = 5
        postprocess_circles = []
        for x, y, r, v in out_circles:
            if all(abs(x - xc) > pixel_threshold or abs(y - yc) > pixel_threshold or abs(r - rc) > pixel_threshold for xc, yc, rc, v in postprocess_circles):
                postprocess_circles.append((x, y, r, v))
            out_circles = postprocess_circles
  
    for x, y, r, v in out_circles:
        output_img = cv2.circle(output_img, (x,y), r, (0,255,0), 2)
    
    cv2.imshow('Imaginea', output_img)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
    return output_img, out_circles
    
def HOUGH_CirclesVariableRadius(img_height, img_width, minRadius, maxRadius):
    print(f"imgHeight:{img_height}\nimgWidth:{img_width}\nRadius Min:{minRadius}\nRadius Max:{maxRadius}")
    
    theta = np.arange(0, 360)
    rs = np.arange(minRadius, maxRadius) #radius interval
    
    cosTheta = np.cos(np.deg2rad(theta))
    sinTheta = np.sin(np.deg2rad(theta))
    
    circleCandidates = []
    for r in rs:
        for t in range(100):
            circleCandidates.append((r, int(r * cosTheta[t]), int(r * sinTheta[t])))
            
def HOUGH_Circle_FunctionFixed(img, radius):
    print(radius)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) 
    gray_blurred = cv2.blur(gray, (3, 3)) 
    detected_circles = cv2.HoughCircles(gray_blurred, cv2.HOUGH_GRADIENT, 1, 20, param1 = 50, param2 = 30, minRadius = radius, maxRadius = radius) 

    if detected_circles is not None: 
        detected_circles = np.uint16(np.around(detected_circles))
        for pt in detected_circles[0, :]: 
            a, b, r = pt[0], pt[1], pt[2] 
            cv2.circle(img, (a, b), r, (0, 255, 0), 2) 
            cv2.circle(img, (a, b), 1, (0, 0, 255), 3) 
            cv2.imshow("Detected Circle(s)", img) 
            cv2.waitKey(0)
    GUIFunction.GUI.progressBar.set(f"{100:.2f}%")
    
def HOUGH_Circle_FunctionVariable(img, minRadius, maxRadius):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) 
    gray_blurred = cv2.blur(gray, (3, 3)) 
    detected_circles = cv2.HoughCircles(gray_blurred, cv2.HOUGH_GRADIENT, 1, 20, param1 = 50, param2 = 30, minRadius = minRadius, maxRadius = maxRadius) 

    if detected_circles is not None: 
        detected_circles = np.uint16(np.around(detected_circles))
        for pt in detected_circles[0, :]: 
            a, b, r = pt[0], pt[1], pt[2] 
            cv2.circle(img, (a, b), r, (0, 255, 0), 2) 
            cv2.circle(img, (a, b), 1, (0, 0, 255), 3) 
            cv2.imshow("Detected Circle(s)", img) 
            cv2.waitKey(0)
    GUIFunction.GUI.progressBar.set(f"{100:.2f}%")