import GUI
import HOUGH #Momentan, nefolosit ca e apelata direct din GUI. Implementat threading?

GUI